# Análise de Clientes – Distribuição Geográfica e Faixa Etária

## Introdução
Este projeto tem como objetivo explorar dados fictícios de clientes, identificando padrões de distribuição geográfica (via DDD) e perfil etário.
A análise busca apoiar estratégias de marketing, segmentação e personalização de campanhas com base em características demográficas.

## Recursos
- Separação de clientes por **DDD** para entender a distribuição geográfica.
- Identificação da **faixa etária** dos clientes.
- Visualizações claras para apoiar decisões estratégicas.
- Storytelling com insights e recomendações práticas.

## Tecnologias Utilizadas
- **Python**
- **Pandas, NumPy** → manipulação e modelagem de dados.
- **Matplotlib, Seaborn, Plotly** → visualização de dados.
- **Jupyter Notebook** → análise interativa e narrativa.

## Como Usar
1. Clone este repositório em sua máquina local.
2. Instale as dependências necessárias:
   ```bash
   pip install -r requirements.txt
   ```
3. Execute os notebooks na pasta `/notebooks`:
   - `01_preparacao_dados.ipynb` → limpeza e preparação do dataset.
   - `02_analise_ddd.ipynb` → análise da distribuição de clientes por DDD.
   - `03_analise_faixa_etaria.ipynb` → análise de idade e grupos etários.
   - `04_storytelling.ipynb` → principais insights e recomendações.

## Exemplos de Insights
- Determinados DDDs concentram mais de **30% da base de clientes**, indicando maior penetração da empresa em regiões específicas.
- A maior parte dos clientes está na faixa de **25 a 34 anos**, sugerindo potencial para campanhas digitais focadas em público jovem-adulto.
- Clientes acima de **65 anos representam menos de 10%**, apontando oportunidade de crescimento em estratégias para esse público.

## Contribuições
Sugestões, melhorias e colaborações são bem-vindas. Abra um pull request ou issue para contribuir.

## Contato
📩 velosogabriel5@gmail.com
